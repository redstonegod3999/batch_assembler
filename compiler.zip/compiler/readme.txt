[-----------------------------------------]
[ Assembly Compiler with Nasm for Windows ]
[ Made by redstonegod3999 on day 05-12-23 ]
[ Hour 16:23.                             ]
[-----------------------------------------]
Hello! This is my compiler for .asm projects! This will only work with NASM.

!!!!!!!
Please write the full file path (for example "C:\Users\exampleuser\Documents\exampleproject\exampleproject.asm") because the compiler
won't recognize the file if you put in %userprofile%.
!!!!!!!

This project is open-source.